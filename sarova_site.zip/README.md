# Sarova — Beauty Lounge

Static landing page for Sarova (pink & beige theme). Deployed on GitHub Pages.
